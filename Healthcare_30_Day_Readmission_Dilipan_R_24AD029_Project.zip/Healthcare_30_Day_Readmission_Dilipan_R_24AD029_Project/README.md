# Predicting 30-Day Hospital Readmission

**Student:** Dilipan R  
**Roll No.:** 24AD029  
**Department:** Artificial Intelligence and Data Science

## Project overview

This project uses the Diabetes 130-US Hospitals for Years 1999–2008 dataset to explore and predict early hospital readmission. The binary target is `1` when `readmitted` is `<30` days and `0` for the other recorded outcomes.

## Project files

- `Healthcare_30_Day_Readmission_Dilipan_R_24AD029.ipynb` — Google Colab notebook for the analysis and figures.
- `Healthcare_30_Day_Readmission_Dilipan_R_24AD029.py` — Python script version of the analysis.
- `requirements.txt` — dependencies used by the analysis.

## Run the notebook

Open the notebook in Google Colab and choose **Runtime → Run all**. It fetches the public dataset from UCI; if that fails, use the CSV upload option in the notebook. The modeling code uses patient-level grouped train, validation, and test splits so that a patient's encounters do not appear in multiple partitions. The patient identifier is used only for grouping and is excluded from model features.

Install dependencies locally with `python -m pip install -r requirements.txt`. The script downloads the dataset from UCI and therefore requires internet access.

## Dataset source

UCI Machine Learning Repository, [Diabetes 130-US Hospitals for Years 1999–2008](https://archive.ics.uci.edu/dataset/296/diabetes+130-us-hospitals+for-years-1999-2008).
